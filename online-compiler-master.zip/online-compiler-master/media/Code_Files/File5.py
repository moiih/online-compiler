print('NarutoFile5')
