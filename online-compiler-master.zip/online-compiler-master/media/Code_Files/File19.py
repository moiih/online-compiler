print("19")
