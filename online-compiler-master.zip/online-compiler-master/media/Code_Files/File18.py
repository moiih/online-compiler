print("18")
